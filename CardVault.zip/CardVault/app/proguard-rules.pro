# ProGuard rules for CardVault
